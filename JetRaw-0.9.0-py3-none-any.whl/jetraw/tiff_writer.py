import numpy as np
import ctypes
import ctypes.util
from .jetraw_tiff import JetrawTiff


class TiffWriter:
    """TiffWriter writes numpy array to a JetRaw compressed TIFF file.

    The goal of TiffWriter is to save the input numpy array/s to a JetRaw
    compressed TIFF file in disk.

    Any TiffWriter instance must be closed when finished, in order to
    do that the user needs to use the method close(). If using the
    feature "with" this close() method is called automatically at the end.

    Remember that TiffWriter instances are not thread-safe.

    """

    def __init__(self, filepath, description=""):
        """Open TIFF file for writing.
        An empty TIFF file is created if there is no input data passed. .
        Parameters
        ----------
        filepat : str, path-like
            File name for output TIFF file
        description : str
            The subject of the image. Must be 7-bit ASCII. Cannot be used with
            the ImageJ or OME formats. Saved with the first page of a series
            only.
        """
        self.description = description
        self.fpath = filepath
        self.image_shape = None
        self._jrtif = None

    def __del__(self):
        self.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()

    def close(self):
        if self._jrtif is not None:
            self._jrtif.close()
        self._jrtif = None

    def write(self, image_buffer):
        image_stack = self._check_and_adapt_input_image(image_buffer)

        # Open file, if not already the case
        if self._jrtif is None:
            self._jrtif = JetrawTiff()
            self._jrtif.open(self.fpath, "w", self.image_shape[1], self.image_shape[0], self.description)
        
        for page in range(image_stack.shape[0]):
            self._jrtif.append_page(image_stack[page])

    def _check_and_adapt_input_image(self, image):
        # verify input image number of dimensions
        if np.ndim(image) == 2:
            # add extra dimension
            image = image[None, :]

        if np.ndim(image) == 3:
            if image.dtype != "uint16":
                raise TypeError(f"Input data {image.dtype} is not supported."
                                "Should be uint16.")

            if self.image_shape is None:
                self.image_shape = image.shape[1:]
            elif self.image_shape != image.shape[1:]:
                raise ValueError("All images in the stack must have the same"
                                 " dimensions.")
        else:
            raise ValueError("Input image data must be 2d (single image) or"
                             " 3d (image stack).")

        return image


def imwrite(output_tiff_filename, input_image, description=""):
    """Write numpy array to a JetRaw compressed TIFF file.
    Refer to the TiffWriter class and its write function for more information.

    Parameters
    ----------
    output_tiff_filename : str, path-like
        File name of output TIFF file to be written into disk.
    input_image : array-like
        Input image buffer. Dimensions are assumed to be image depth,
        length, width.
        None is not taken into account for the moment.
    description : str
        The subject of the image. Saved with the first page only.

    Returns
    -------
    None

    """
    # loop through input image pages and append them to output tiff container
    with TiffWriter(output_tiff_filename, description) as jetraw_writer:
        jetraw_writer.write(input_image)